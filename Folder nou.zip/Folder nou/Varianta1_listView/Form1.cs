﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Varianta1_listView
{
    public partial class Form1 : Form
    {
        public ProdusRepository _produseRepository = new ProdusRepository();
        public List<Produs> _produse = new List<Produs>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;
            //listView1.FullRowSelect = true;
            listView1.Columns.Add("CodProdus",100);
            listView1.Columns.Add("Denumire", 100);
            listView1.Columns.Add("Pret", 100);
            listView1.Columns.Add("Cantitate", 100);

            _produse = new ProdusRepository().GetProduse();
            //_produse = new ProdusRepository().GetProduse();

            foreach (var produs in _produse)
            {
                var item = new ListViewItem(produs.codProdus.ToString());
                item.SubItems.Add(produs.denumire);
                item.SubItems.Add(produs.pret.ToString());
                item.SubItems.Add(produs.cantitate.ToString());

                item.Tag = produs;

                listView1.Items.Add(item);
            }
        }

        private void adaugaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AdaugaProdusForm();
            form.Show();
        }

        private void buttonSterge_Click(object sender, EventArgs e)
        {
            var selectedItem = listView1.SelectedItems[0];
            var produs = (Produs)selectedItem.Tag;

            _produseRepository.Sterge(produs);

            listView1.Items.Remove(selectedItem);


        }

        private void binarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter=("Fisiere binare|*.bin");
            
            if(dialog.ShowDialog()==DialogResult.OK)
            {
               using(var stream=new FileStream(dialog.FileName,FileMode.OpenOrCreate))
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(stream, _produse);
                }
            }

        }

        private void xmlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            //ca sa selectez doar fisierele xml:
            dialog.Filter = "XML files|*.xml";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var serializer = new XmlSerializer(typeof(List<Produs>)); //singura diferenta fata de binar e la linia asta!!
                    serializer.Serialize(stream, _produse);
                }
            }

        }

        private void csvToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
