﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Varianta1_listView
{
    public class ProdusRepository
    {
        public string _connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\OneDrive\\Documente\\Ppproduse.mdf;Integrated Security=True;Connect Timeout=30";

        public List<Produs> GetProduse()
        {
            var lista = new List<Produs>();

            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();

                using(var command=new SqlCommand("SELECT codProdus,denumire,pret,cantitate FROM Produse",connection))
                {
                    var reader = command.ExecuteReader();
                    while(reader.Read())
                    {
                        var produs = new Produs();

                        produs.codProdus = reader.GetInt32(reader.GetOrdinal("codProdus"));
                        produs.denumire = reader.GetString(reader.GetOrdinal("denumire"));
                        produs.pret = reader.GetDecimal(reader.GetOrdinal("pret"));
                        produs.cantitate = reader.GetInt32(reader.GetOrdinal("cantitate"));

                        lista.Add(produs);
                    }
                }
            }

            return lista;

        }

        public void Salveaza(Produs produs)
        {
            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using(var command=new SqlCommand("INSERT INTO Produse(denumire,pret,cantitate) VALUES(@denumire,@pret,@cantitate)",connection))
                {
                    command.Parameters.AddWithValue("denumire",produs.denumire);
                    command.Parameters.AddWithValue("pret", produs.pret);
                    command.Parameters.AddWithValue("cantitate", produs.cantitate);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void Sterge(Produs produs)
        {
            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using(var command=new SqlCommand("DELETE FROM Produse WHERE codProdus=@codProdus",connection))
                {
                    command.Parameters.AddWithValue("codProdus", produs.codProdus);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
