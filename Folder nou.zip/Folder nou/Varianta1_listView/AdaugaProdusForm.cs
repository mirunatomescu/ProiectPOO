﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varianta1_listView
{
    public partial class AdaugaProdusForm : Form
    {
        public ProdusRepository _produseRepository = new ProdusRepository();
        public List<Produs> _produse = new List<Produs>();
        public AdaugaProdusForm()
        {
            InitializeComponent();
        }

        private void buttonAdauga_Click(object sender, EventArgs e)
        {
            var produs = new Produs();
            produs.denumire = textBoxDenumire.Text;
            produs.pret = (decimal)numericUpDownPret.Value;
            produs.cantitate = (int)numericUpDownCantitate.Value;

            _produseRepository.Salveaza(produs);
            Close();
        }
    }
}
