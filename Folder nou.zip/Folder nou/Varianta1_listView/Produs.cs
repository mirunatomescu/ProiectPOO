﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Varianta1_listView
{
    [Serializable]
    public class Produs
    {
        public int codProdus { get; set; }
        public string denumire { get; set; }
        public decimal pret { get; set; }
        public int cantitate { get; set; }
        public override string ToString()
        {
            return $"{codProdus},{denumire},{pret},{cantitate}";
        }
    }
}
