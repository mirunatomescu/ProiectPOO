﻿namespace Varianta1_listView
{
    partial class AdaugaProdusForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxDenumire = new System.Windows.Forms.TextBox();
            this.numericUpDownPret = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCantitate = new System.Windows.Forms.NumericUpDown();
            this.buttonAdauga = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPret)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantitate)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(51, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // textBoxDenumire
            // 
            this.textBoxDenumire.Location = new System.Drawing.Point(179, 49);
            this.textBoxDenumire.Name = "textBoxDenumire";
            this.textBoxDenumire.Size = new System.Drawing.Size(153, 22);
            this.textBoxDenumire.TabIndex = 3;
            // 
            // numericUpDownPret
            // 
            this.numericUpDownPret.Location = new System.Drawing.Point(179, 134);
            this.numericUpDownPret.Name = "numericUpDownPret";
            this.numericUpDownPret.Size = new System.Drawing.Size(153, 22);
            this.numericUpDownPret.TabIndex = 4;
            // 
            // numericUpDownCantitate
            // 
            this.numericUpDownCantitate.Location = new System.Drawing.Point(179, 206);
            this.numericUpDownCantitate.Name = "numericUpDownCantitate";
            this.numericUpDownCantitate.Size = new System.Drawing.Size(153, 22);
            this.numericUpDownCantitate.TabIndex = 5;
            // 
            // buttonAdauga
            // 
            this.buttonAdauga.Location = new System.Drawing.Point(151, 295);
            this.buttonAdauga.Name = "buttonAdauga";
            this.buttonAdauga.Size = new System.Drawing.Size(96, 41);
            this.buttonAdauga.TabIndex = 6;
            this.buttonAdauga.Text = "Adauga";
            this.buttonAdauga.UseVisualStyleBackColor = true;
            this.buttonAdauga.Click += new System.EventHandler(this.buttonAdauga_Click);
            // 
            // AdaugaProdusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(846, 509);
            this.Controls.Add(this.buttonAdauga);
            this.Controls.Add(this.numericUpDownCantitate);
            this.Controls.Add(this.numericUpDownPret);
            this.Controls.Add(this.textBoxDenumire);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdaugaProdusForm";
            this.Text = "AdaugaProdusForm";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPret)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantitate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxDenumire;
        private System.Windows.Forms.NumericUpDown numericUpDownPret;
        private System.Windows.Forms.NumericUpDown numericUpDownCantitate;
        private System.Windows.Forms.Button buttonAdauga;
    }
}