﻿namespace Varianta2_dataGridView
{
    partial class AdaugaProdusForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxDenumire = new System.Windows.Forms.TextBox();
            this.numericUpDownPret = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownCantitate = new System.Windows.Forms.NumericUpDown();
            this.buttonAdauga = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPret)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantitate)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Denumire :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 213);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cantitate :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Pret :";
            // 
            // textBoxDenumire
            // 
            this.textBoxDenumire.Location = new System.Drawing.Point(209, 34);
            this.textBoxDenumire.Name = "textBoxDenumire";
            this.textBoxDenumire.Size = new System.Drawing.Size(198, 22);
            this.textBoxDenumire.TabIndex = 3;
            this.textBoxDenumire.TextChanged += new System.EventHandler(this.textBoxDenumire_TextChanged);
            // 
            // numericUpDownPret
            // 
            this.numericUpDownPret.Location = new System.Drawing.Point(209, 119);
            this.numericUpDownPret.Name = "numericUpDownPret";
            this.numericUpDownPret.Size = new System.Drawing.Size(198, 22);
            this.numericUpDownPret.TabIndex = 4;
            this.numericUpDownPret.ValueChanged += new System.EventHandler(this.numericUpDownPret_ValueChanged);
            // 
            // numericUpDownCantitate
            // 
            this.numericUpDownCantitate.Location = new System.Drawing.Point(209, 206);
            this.numericUpDownCantitate.Name = "numericUpDownCantitate";
            this.numericUpDownCantitate.Size = new System.Drawing.Size(198, 22);
            this.numericUpDownCantitate.TabIndex = 5;
            this.numericUpDownCantitate.ValueChanged += new System.EventHandler(this.numericUpDownCantitate_ValueChanged);
            // 
            // buttonAdauga
            // 
            this.buttonAdauga.Location = new System.Drawing.Point(223, 306);
            this.buttonAdauga.Name = "buttonAdauga";
            this.buttonAdauga.Size = new System.Drawing.Size(101, 39);
            this.buttonAdauga.TabIndex = 6;
            this.buttonAdauga.Text = "Adauga";
            this.buttonAdauga.UseVisualStyleBackColor = true;
            this.buttonAdauga.Click += new System.EventHandler(this.buttonAdauga_Click);
            // 
            // AdaugaProdusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonAdauga);
            this.Controls.Add(this.numericUpDownCantitate);
            this.Controls.Add(this.numericUpDownPret);
            this.Controls.Add(this.textBoxDenumire);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "AdaugaProdusForm";
            this.Text = "AdaugaProdusForm";
            this.Load += new System.EventHandler(this.AdaugaProdusForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownPret)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownCantitate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxDenumire;
        private System.Windows.Forms.NumericUpDown numericUpDownPret;
        private System.Windows.Forms.NumericUpDown numericUpDownCantitate;
        private System.Windows.Forms.Button buttonAdauga;
    }
}