﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Varianta2_dataGridView
{
    public partial class AdaugaProdusForm : Form
    {

        public ProdusRepository _produsRepository = new ProdusRepository();
   
        public AdaugaProdusForm()
        {
            InitializeComponent();
           
            
        }

        private void AdaugaProdusForm_Load(object sender, EventArgs e)
        {

        }

        private void textBoxDenumire_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDownPret_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDownCantitate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonAdauga_Click(object sender, EventArgs e)
        {
            var produs = new Produs();

            produs.denumire = textBoxDenumire.Text;
            produs.pret = (decimal)numericUpDownPret.Value;
            produs.cantitate = (int)numericUpDownCantitate.Value;

            _produsRepository.Salveaza(produs);

            Close();
        }
    }
}
