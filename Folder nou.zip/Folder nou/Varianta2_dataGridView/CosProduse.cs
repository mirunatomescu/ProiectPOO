﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Varianta2_dataGridView
{
    public   class CosProduse
    {
        List<Produs> produse = new List<Produs>();
    }
}
