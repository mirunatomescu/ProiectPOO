﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Varianta2_dataGridView
{
    
    public class ProdusRepository
    {
        public string _connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\OneDrive\\Documente\\MProduse.mdf;Integrated Security=True;Connect Timeout=30";

        public List<Produs> GetProduse()
        {
            var list = new List<Produs>();

            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();

                using(var command=new SqlCommand("SELECT codProdus,denumire,pret,cantitate FROM MProduse",connection))
                {
                    var reader = command.ExecuteReader();
                    while(reader.Read())
                    {
                        var produs = new Produs();

                        produs.codProdus = reader.GetInt32(reader.GetOrdinal("codProdus"));
                        produs.denumire = reader.GetString(reader.GetOrdinal("denumire"));
                        produs.pret = reader.GetDecimal(reader.GetOrdinal("pret"));
                        produs.cantitate = reader.GetInt32(reader.GetOrdinal("cantitate"));

                        list.Add(produs);

                    }
                }
            }

            return list;
        }

        public void Salveaza(Produs produs)
        {
            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using(var command=new SqlCommand("INSERT INTO MProduse(denumire,pret,cantitate) VALUES(@denumire,@pret,@cantitate)",connection))
                {
                    command.Parameters.AddWithValue("denumire", produs.denumire);
                    command.Parameters.AddWithValue("pret", produs.pret);
                    command.Parameters.AddWithValue("cantitate", produs.cantitate);

                    command.ExecuteNonQuery();

                }
            }
        }

        public void Sterge(Produs produs)
        {
            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DELETE FROM MProduse WHERE codProdus=@codProdus",connection))
                {
                    command.Parameters.AddWithValue("codProdus", produs.codProdus);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
