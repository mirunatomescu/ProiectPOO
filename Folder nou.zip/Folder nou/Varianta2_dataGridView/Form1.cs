﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Varianta2_dataGridView
{
    public partial class Form1 : Form
    {

        public ProdusRepository _produsRepository = new ProdusRepository();
        public List<Produs> _produse;
        public Form1()
        {
            InitializeComponent();

        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mProduseDataSet.MProduse' table. You can move, or remove it, as needed.
            this.mProduseTableAdapter.Fill(this.mProduseDataSet.MProduse);

        }

        private void adaugaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AdaugaProdusForm();
            form.Show();
        }

        private void buttonSterge_Click(object sender, EventArgs e)
        {
            var selectedRow = dataGridView1.SelectedRows[0];

            // Extragem codProdus din coloana corespunzătoare (presupunem coloana 0 are codProdus)
            int codProdus = Convert.ToInt32(selectedRow.Cells["codProdus"].Value);

            // Creăm un obiect produs cu codul extras
            var produsDeSters = new Produs { codProdus = codProdus };

            // Apelăm metoda de ștergere din repository
            _produsRepository.Sterge(produsDeSters);

            // Reîncărcăm datele în DataGridView (reîncarcă datele din baza de date)
           this.mProduseTableAdapter.Fill(this.mProduseDataSet.MProduse);

            MessageBox.Show("Produs șters cu succes!");
        }

        private void binarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //var dialog = new SaveFileDialog();
            //dialog.Filter = "Fisiere binare|*.bin";
            //if (dialog.ShowDialog() == DialogResult.OK)
            //{
            //    using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
            //    {
            //        var formatter = new BinaryFormatter();
            //        formatter.Serialize(stream, _produse);
            //    }
            //}

        }

        private void xmlToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter=("Fisere xml|*.xml");
            if(dialog.ShowDialog()==DialogResult.OK)
            {
                using(var stream=new FileStream(dialog.FileName,FileMode.OpenOrCreate))
                {
                    var serializer = new XmlSerializer(typeof(List<Produs>));
                    serializer.Serialize(stream, _produse);
                }
            }
        }

        private void csvToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter = ("Fisere csv|*.csv");
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var serializer = new XmlSerializer(typeof(List<Produs>));
                    serializer.Serialize(stream, _produse);
                }
            }
        }

        private void numarToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {
            var nrProduse = dataGridView1.RowCount-1;
            toolStripStatusNrProduse.Text = $"Nr produse: {nrProduse}";

        }

        private void toolStripStatusLabelValoareTotala_Click(object sender, EventArgs e)
        {
            decimal valoareTotala = 0;

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow) // ignoră rândul gol de la final
                {
                    decimal pret = Convert.ToDecimal(row.Cells[2].Value);
                    int cantitate = Convert.ToInt32(row.Cells[3].Value);
                    valoareTotala += pret * cantitate;
                }
            }

            toolStripStatusLabelValoareTotala.Text = "Valoare totală: " + valoareTotala + " lei";
        }

        private void binarToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter = "Fisiere binare|*.bin";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(stream, _produse);
                }
            }
        }

        private void xmlToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            dialog.Filter = "Fisiere xml|*.xml";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var serializer = new XmlSerializer(typeof(List<Produs>));
                    serializer.Serialize(stream, _produse);
                }
            }
        }

        private void csvToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            //ca sa selectez doar fisierele csv:
            dialog.Filter = "CSV files|*.csv";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    using (var writer = new StreamWriter(stream))
                    {
                        foreach (var angajat in _produse)
                        {
                            writer.WriteLine(angajat.ToString());
                        }
                    }
                }
            }
        }

        private void adaugaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            var form = new AdaugaProdusForm();
            form.Show();
        }
    }
}
