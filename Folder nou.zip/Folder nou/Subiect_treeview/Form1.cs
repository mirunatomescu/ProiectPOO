﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Subiect_treeview
{
    public partial class Form1 : Form
    {

        private AngajatRepository _angajatRepository = new AngajatRepository();
        private List<Angajat> _angajati;

        //pt cerinta cu tiparire

        private int _currentY = 40;
        public Form1()
        {
            InitializeComponent();

            BuildTree();

            angajatiListView.View = View.Details;
            angajatiListView.Columns.Add("Nume");
            angajatiListView.Columns.Add("Salariu");
            angajatiListView.Columns.Add("Manager");


            //pt cerinta 9, listview focus
            RegisterKeyEvents();


        }
        //asta pt cerinta cu stergere
        private void RegisterKeyEvents()
        {
            angajatiListView.KeyUp += (s, e) =>
            {
                var listView = s as ListView;
                if (e.KeyCode == Keys.Delete)
                {
                    if (listView.SelectedItems.Count > 0)
                    {
                        foreach (var item in listView.SelectedItems)
                        {
                            var listViewItem = item as ListViewItem;
                            var angajat = listViewItem.Tag as Angajat;

                            if(_angajati.Any(x=>x.CodManager==angajat.Cod))
                            {
                                MessageBox.Show($"Nu se pooate sterge angajatul {angajat.Nume}deoarece este manager", "Eroare", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            else
                            {
                                _angajatRepository.Sterge(angajat);
                                BuildTree();
                                angajatiListView.Items.Clear();
                            }
                        }
                    }
                }
            };
        }

        private void BuildTree()
        {
            treeViewAngajati.Nodes.Clear();

            _angajati = _angajatRepository.GetAngajati();

            var manager = _angajati.First(x => x.CodManager == null);

            var node = new TreeNode(manager.Nume);
            node.Tag = manager;

            treeViewAngajati.Nodes.Add(node);
            BuildTree(manager, node);
        }

        private void BuildTree(Angajat manager, TreeNode root)
        {
            var angajati = _angajati.Where(x => x.CodManager == manager.Cod);
            foreach(var angajat in angajati)
            {
                var node = new TreeNode(angajat.Nume);
                node.Tag = angajat;
                root.Nodes.Add(node);
                BuildTree(angajat, node);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void treeViewAngajati_AfterSelect(object sender, TreeViewEventArgs e)
        {
            angajatiListView.Items.Clear();

            var manager = (Angajat)e.Node.Tag;

            var angajatiInSubordine = _angajati.Where(x => x.CodManager == manager.Cod);

            foreach(var angajat in angajatiInSubordine)
            {
                var item = new ListViewItem(angajat.Nume);
                item.SubItems.Add(angajat.Salariu.ToString());
                item.SubItems.Add(manager.Nume);
                item.Tag = angajat;

                angajatiListView.Items.Add(item);
            }
        }

        private void adaugaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new AdaugaAngajatForm();
            form.ShowDialog();

            BuildTree();
        }

        private void binarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            //ca sa selectez doar fisierele binare:
            dialog.Filter = "Binary files|*.bin";
            if(dialog.ShowDialog()==DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var formatter = new BinaryFormatter();
                    formatter.Serialize(stream, _angajati);
                }
            }
        }

        private void xMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            //ca sa selectez doar fisierele xml:
            dialog.Filter = "XML files|*.xml";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    var serializer = new XmlSerializer(typeof(List<Angajat>)); //singura diferenta fata de binar e la linia asta!!
                    serializer.Serialize(stream, _angajati);
                }
            }
        }

        private void cSVToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var dialog = new SaveFileDialog();
            //ca sa selectez doar fisierele csv:
            dialog.Filter = "CSV files|*.csv";
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                using (var stream = new FileStream(dialog.FileName, FileMode.OpenOrCreate))
                {
                    using(var writer=new StreamWriter(stream))
                    {
                        foreach(var angajat in _angajati)
                        {
                            writer.WriteLine(angajat.ToString());
                        }
                    }
                }
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var document = new PrintDocument();
            document.PrintPage += (s,ev)=>
            {
                ev.Graphics.DrawString("Nume angajajt", new Font("Verdana", 10, FontStyle.Bold), Brushes.Black, new PointF(20, 20));
                ev.Graphics.DrawString("Salariu", new Font("Verdana", 10, FontStyle.Bold), Brushes.Black, new PointF(400, 20));
                ev.Graphics.DrawString("Nume manager", new Font("Verdana", 10, FontStyle.Bold), Brushes.Black, new PointF(640, 20));

                var manager = _angajati.First(x => x.CodManager == null);

                PrintAngajatCurent(ev, manager,20);

                ev.HasMorePages = false;
            };

            var dialog = new PrintPreviewDialog()
            {
                Document = document,
                Width=800,
                Height=1200

            };

            dialog.ShowDialog();
        }

        private void PrintAngajatCurent(PrintPageEventArgs ev, Angajat manager, int x)
        {
            
            ev.Graphics.DrawString(manager.Nume, new Font("Verdana", 10), Brushes.Black, new PointF(x, _currentY));
            ev.Graphics.DrawString(manager.Salariu.ToString(), new Font("Verdana", 10), Brushes.Black, new PointF(400, _currentY));
            if(manager.CodManager!=null)
            {
                var managerulManagerului = _angajati.First(a => a.Cod == manager.CodManager);
                ev.Graphics.DrawString(managerulManagerului.Nume.ToString(), new Font("Verdana", 10), Brushes.Black, new PointF(640, _currentY));
            }

            _currentY += 20;
            


            var angajatiInSubordine = _angajati.Where(a => a.CodManager == manager.Cod);
            foreach(var angajat in angajatiInSubordine)
            {
                PrintAngajatCurent(ev, angajat, x + 20);
            }
        }

        private void chartToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var form = new ChartForm();
            form.ShowDialog();
        }

        private void menuStrip3_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void angajatiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
