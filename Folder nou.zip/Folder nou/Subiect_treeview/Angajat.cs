﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Subiect_treeview
{
    [Serializable]
    public class Angajat
    {
        public int Cod { get; set; }
        public string Nume { get; set; }
        public double Salariu { get; set; }
        public int? CodManager { get; set; }

        public override string ToString()
        {
            return $"{Cod},{Nume},{Salariu},{CodManager}";
        }
    }
}
