﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Subiect_treeview
{
    public partial class ChartForm : Form
    {

        private AngajatRepository _angajatRepository = new AngajatRepository();
        public ChartForm()
        {
            InitializeComponent();
            var angajati = _angajatRepository.GetAngajati();

            var coduriManager = angajati.Where(x => x.CodManager != null).Select(x => x.CodManager).Distinct();
            var manageri = angajati.Where(x => coduriManager.Contains(x.Cod));

            var nonManageri = angajati.Where(x => !manageri.Contains(x));

            var sumManageri = manageri.Sum(x => x.Salariu);
            var sumNoManageri = nonManageri.Sum(x => x.Salariu);

            salariiChart.ChartAreas.Clear();
            salariiChart.Series.Clear();

            var area = new ChartArea();
            area.Name = "PieChartArea";
            salariiChart.ChartAreas.Add(area);

            var series = new Series();
            series.ChartArea = "PieChartArea";
            series.ChartType = SeriesChartType.Pie;
            series.IsValueShownAsLabel = true;

            series.Points.AddXY("Manageri", sumManageri);
            series.Points.AddXY("Non-manageri", sumNoManageri);

            salariiChart.Series.Add(series);
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void ChartForm_Load(object sender, EventArgs e)
        {

        }
    }
}
