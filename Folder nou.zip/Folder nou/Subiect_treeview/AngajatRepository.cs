﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Subiect_treeview
{
    public class AngajatRepository
    {
        private string _connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\" +
            "OneDrive\\Documente\\angajati.mdf;Integrated Security=True;Connect Timeout=30";
        public List<Angajat> GetAngajati()
        {
            var list = new List<Angajat>();

            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();

                using(var command=new SqlCommand("SELECT Cod, Nume, Salariu, CodManager FROM Angajati",connection))
                {
                    var reader=command.ExecuteReader();
                    while(reader.Read())
                    {
                        var angajat = new Angajat();
                        angajat.Cod = reader.GetInt32(reader.GetOrdinal("Cod"));
                        angajat.Nume = reader.GetString(reader.GetOrdinal("Nume"));
                        angajat.Salariu = reader.GetDouble(reader.GetOrdinal("Salariu"));

                        int index = reader.GetOrdinal("CodManager");

                        if(!reader.IsDBNull(index))
                        {
                            angajat.CodManager = reader.GetInt32(index);
                        }

                        list.Add(angajat);
                    }
                }
            }

            return list;
        }

        public void Salveaza(Angajat angajat)

        {
            using(var connection=new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("INSERT INTO Angajati (Nume, Salariu, CodManager) VALUES(@Nume,@Salariu,@CodManager)", connection))
                {
                    command.Parameters.AddWithValue("Nume", angajat.Nume);
                    command.Parameters.AddWithValue("Salariu", angajat.Salariu);
                    command.Parameters.AddWithValue("CodManager", angajat.CodManager);

                    command.ExecuteNonQuery();



                }



            }
        }
        //pt sub 9
        public void Sterge(Angajat angajat)

        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new SqlCommand("DELETE FROM Angajati WHERE Cod=@Cod", connection))
                {
                    command.Parameters.AddWithValue("Cod", angajat.Cod);
                    

                    command.ExecuteNonQuery();



                }



            }
        }
    }
}
