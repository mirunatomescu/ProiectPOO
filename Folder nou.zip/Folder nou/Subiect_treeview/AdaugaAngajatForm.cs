﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Subiect_treeview
{
    public partial class AdaugaAngajatForm : Form
    {
        private AngajatRepository _angajatRepository = new AngajatRepository();
        public AdaugaAngajatForm()
        {
            InitializeComponent();

            var angajati = _angajatRepository.GetAngajati().OrderByDescending(x=>x.Nume).ToList();

            managerComboBox.DataSource = angajati;

            managerComboBox.DisplayMember = "Nume";
            managerComboBox.ValueMember = "Cod";
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            var angajat = new Angajat();

            angajat.Nume = textBoxNume.Text;
            angajat.Salariu = (double)numericUpDownSalariu.Value;
            angajat.CodManager = (int)managerComboBox.SelectedValue;

            _angajatRepository.Salveaza(angajat);
            Close();
        }

        private void AdaugaAngajatForm_Load(object sender, EventArgs e)
        {

        }

        private void numericUpDownSalariu_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
